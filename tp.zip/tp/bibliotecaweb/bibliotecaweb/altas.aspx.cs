﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace bibliotecaweb
{
    public partial class altas : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            String s;
            try
            {
                s = ConfigurationManager.ConnectionStrings["miconexion"].ConnectionString;
                SqlConnection conexion = new SqlConnection(s);

                conexion.Open();
                SqlCommand comando = new SqlCommand("insert into libros(nombre,genero,autor) values('" + this.TextBox1.Text + "','" + this.TextBox2.Text + "','" + this.TextBox3.Text + "')", conexion);
                comando.ExecuteNonQuery();
                this.Label4.Text = "estado: Se registró el libro";
                conexion.Close();
            }
            catch (SqlException ex)
            {
                this.Label4.Text = ex.Message;
            }
        }
        }

       
}