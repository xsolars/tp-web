﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Data.OleDb;
using System.Text;
using System.IO;

namespace bibliotecaweb
{
    public partial class delete : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        { String s;
            try
            {
                s = ConfigurationManager.ConnectionStrings["miconexion"].ConnectionString;
                SqlConnection conexion = new SqlConnection(s);

            //utilizamos el procedimiento alamacenado creado para eliminar por cÃ³digo
            SqlCommand cmd = new SqlCommand("eliminarlibro", conexion);
            //especificamos que el comando es un procedimiento almacenado
            cmd.CommandType = CommandType.StoredProcedure;
            //creamos los parametros que usaremos
            cmd.Parameters.Add("@id_libro", SqlDbType.Int);
            //asignamos el valor de los textbox a los parametros
            cmd.Parameters["@id_libro"].Value = TextBox1.Text;


            conexion.Open();


            int cant = cmd.ExecuteNonQuery();

            if (cant == 1)

                this.Label2.Text = "Se borro el libro";

            else

                this.Label2.Text = "No existe un libro con dicho id";


            conexion.Close(); ;
           
          
        }
    }