﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Data.OleDb;
using System.Text;
using System.IO;

namespace bibliotecaweb
{
    public partial class modif : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            String s;
            try
            {
                s = ConfigurationManager.ConnectionStrings["miconexion"].ConnectionString;
                SqlConnection conexion = new SqlConnection(s);

       DataTable dt = new DataTable();
        String strSql;
        strSql = "busca";
        SqlDataAdapter da = new SqlDataAdapter(strSql, conexion);
        conexion.Open();
        da.SelectCommand.CommandType = CommandType.StoredProcedure;
        da.SelectCommand.Parameters.Add("@id_libro", SqlDbType.Int).Value = TextBox1.Text;
        da.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            TextBox2.Text = dt.Rows[0]["nombre"].ToString();
            TextBox3.Text = dt.Rows[0]["genero"].ToString();
            TextBox4.Text = dt.Rows[0]["autor"].ToString();
        }
        else
        {
            Label1.Text = "Usuario no encontrado";
         

        }

    }
}

        protected void Button2_Click(object sender, EventArgs e)
        { String s;
            try
            {
                s = ConfigurationManager.ConnectionStrings["miconexion"].ConnectionString;
                SqlConnection conexion = new SqlConnection(s);
            
        SqlCommand cmd = new SqlCommand("actualiza", conexion);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@id_libro", SqlDbType.Int);
        cmd.Parameters.Add("@nombre", SqlDbType.VarChar);
        cmd.Parameters.Add("@genero", SqlDbType.VarChar);
        cmd.Parameters.Add("@autor", SqlDbType.VarChar);

        cmd.Parameters["@id_libro"].Value = TextBox1.Text;
        cmd.Parameters["@nombre"].Value = TextBox2.Text;
        cmd.Parameters["@genero"].Value = TextBox3.Text;
        cmd.Parameters["@autor"].Value = TextBox4.Text;
        
        conexion.Open();
        int cant = cmd.ExecuteNonQuery();
        
        if(cant == 1)
        
        Label5.Text = "Usuario actualizado...";

        else
            Label5.Text = "no encontrado..";

        conexion.Close();
        }