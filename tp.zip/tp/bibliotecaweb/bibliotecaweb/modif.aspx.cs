﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Data.OleDb;
using System.Text;
using System.IO;

namespace bibliotecaweb
{
    public partial class modif : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            String s;
            try
            {
                s = ConfigurationManager.ConnectionStrings["miconexion"].ConnectionString;
                SqlConnection conexion = new SqlConnection(s);

         //utilizamos el procedimiento alamacenado creado para buscar
        SqlCommand cmd = new SqlCommand("buscar", conexion);
        //especificamos que el comando es un procedimiento almacenado
        cmd.CommandType = CommandType.StoredProcedure;
        //creamos los parametros que usaremos
        cmd.Parameters.Add("@id_libro", SqlDbType.Int);
        //asignamos el valor de los textbox a los parametros
        cmd.Parameters["@id:libro"].Value = TextBox1.Text;



        //abrimos conexion
        conexion.Open();
        //ejecutamos la instruccion con ExcecuteNonQuerry indicando que no retorna registros.
        cmd.ExecuteNonQuery();
        Label5.Text = "Usuario encontrado...";
        //cerramos conexion
        conexion.Close();
    }
}

        protected void Button2_Click(object sender, EventArgs e)
        { String s;
            try
            {
                s = ConfigurationManager.ConnectionStrings["miconexion"].ConnectionString;
                SqlConnection conexion = new SqlConnection(s);
            
        SqlCommand cmd = new SqlCommand("actualiza", conexion);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@id_libro", SqlDbType.Int);
        cmd.Parameters.Add("@nombre", SqlDbType.VarChar);
        cmd.Parameters.Add("@genero", SqlDbType.VarChar);
        cmd.Parameters.Add("@autor", SqlDbType.VarChar);

        cmd.Parameters["@id_libro"].Value = TextBox1.Text;
        cmd.Parameters["@nombre"].Value = TextBox2.Text;
        cmd.Parameters["@genero"].Value = TextBox3.Text;
        cmd.Parameters["@autor"].Value = TextBox4.Text;
        
        conexion.Open();
        int cant = cmd.ExecuteNonQuery();
        
        if(cant == 1)
        
        Label5.Text = "Usuario actualizado...";

        else
            Label5.Text = "no encontrado..";

        conexion.Close();
        }