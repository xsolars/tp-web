USE [libreria_46]
GO

/****** Object:  StoredProcedure [dbo].[actualiza]    Script Date: 22/9/2022 12:23:17 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

create procedure [dbo].[actualiza]
@id_libro int,@nombre nchar(100),@genero nchar(100),@autor nchar(100)
as
begin
UPDATE [dbo].[libros]
   SET [nombre] = @nombre
      ,[genero] = @genero
      ,[autor] = @autor
 WHERE libros.id_libro=@id_libro
end
GO

