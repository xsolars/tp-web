USE [libreria_46]
GO

/****** Object:  StoredProcedure [dbo].[busca]    Script Date: 22/9/2022 12:23:27 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

create procedure [dbo].[busca]
@id_libro int
as
select*from libros
where id_libro=@id_libro
GO

