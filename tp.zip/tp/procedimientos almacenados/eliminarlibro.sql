USE [libreria_46]
GO

/****** Object:  StoredProcedure [dbo].[eliminarlibro]    Script Date: 22/9/2022 12:23:50 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

create procedure [dbo].[eliminarlibro]
@id_libro int
as
delete libros 
where id_libro= @id_libro
GO

