USE [libreria_46]
GO

/****** Object:  StoredProcedure [dbo].[insertarlibros]    Script Date: 22/9/2022 12:24:01 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

create procedure [dbo].[insertarlibros]
@nombre varchar(100), @genero varchar(100), @autor varchar(100)
as 
insert into libros
values (@nombre,@genero,@autor)
GO

